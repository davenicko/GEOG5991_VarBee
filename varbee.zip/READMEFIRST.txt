This zip file contains the following files:

./READMEFIRST - This file documenting what the other files mean

./varbee/README - A short description of the model and how to use it

./varbee/varbee.docx - A longer description of how the model has been constructed

./varbee/environment.csv - An example environment file

./varbee/varbee.py - The main part of the model, containing all the classes
					 required to run it

./varbee/model.py - The driver for the model which creates the output heatmap
					and population graphs. This works faster than the animated
					version which necessarily takes greater computer power to
					run. If lots of runs will be performed, it makes sense to
					use this.

./varbee/model_animated.py - A version of the model which displays the agents
						 	 and environment in action. Very interesting to
							 watch, but more useful information can be taken
							 from the model.py driver more efficiently.
